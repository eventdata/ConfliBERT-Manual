The Re3d dataset is originally from (https://github.com/dstl/re3d).

We re-splitted and processed its CONLL format from (https://github.com/juand-r/entity-recognition-datasets/tree/master/data/re3d)
