IndiaPoliceEvents_sents.json:  An example for classification tasks.

re3d.json: An example for NER tasks.

The option of "tasks" includes: ["binary", "multiclass", "multilabel", "ner"]
