from flask import Flask, render_template, request, jsonify
from simpletransformers.classification import MultiLabelClassificationModel

app = Flask(__name__)

# Load the model
MODEL_PATH = "outputs/best_model" # Based on the structure you provided earlier
ARCHITECTURE = "bert" # Assuming you're using a BERT-based architecture for Conflibert

model = MultiLabelClassificationModel(ARCHITECTURE, MODEL_PATH)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    text = request.form['text']
    predictions, raw_outputs = model.predict([text])
    # Format and send your prediction result as desired
    return jsonify(predictions=predictions.tolist())

if __name__ == '__main__':
    app.run(debug=True)
